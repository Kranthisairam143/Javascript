let counterelement = document.getElementById("counter value");

function increase() {
    let previouscountervalue = counterelement.textContent;
    let updatedcountervalue = parseInt(previouscountervalue) + 1;
    counterelement.textContent = updatedcountervalue
    if (updatedcountervalue > 0) {
        counterelement.style.color = "green";
    } else if (updatedcountervalue < 0) {
        counterelement.style.color = "red";
    } else {
        counterelement.style.color = "black";
    }
}

function decrease() {
    let previouscountervalue = counterelement.textContent;
    let updatedcountervalue = parseInt(previouscountervalue) - 1;
    counterelement.textContent = updatedcountervalue;
    if (updatedcountervalue > 0) {
        counterelement.style.color = "green";
    } else if (updatedcountervalue < 0) {
        counterelement.style.color = "red";
    } else {
        counterelement.style.color = "black";
    }


}

function reset() {
    let updatedcountervalue = 0;
    counterelement.textContent = updatedcountervalue;
    counterelement.style.color = "black";



}