let todoItemsContainer = document.getElementById("todoItemsContainer");
let todolist = [{
        text: "Hulk"
    },
    {
        text: "captain america"
    },
    {
        text: "Iron man"
    },
];

function createAndAppendTodo(todo) {
    let todoElement = document.createElement('li');
    todoElement.classList.add("todo-items-container", "d-flex", "flex-row");
    todoItemsContainer.appendChild(todoElement);
    let input = document.createElement('input');
    input.type = "checkbox";
    input.id = "checkboxme";
    input.classList.add("checkbox-input");
    todoElement.appendChild(input);

    let label = document.createElement('div');
    label.classList.add("label-container", "d-flex", "flex-row");
    todoElement.appendChild(label);
    let labelElement = document.createElement('label');
    label.htmlfor = "checkboxme";
    labelElement.classList.add("checkbox-label");
    label.textContent = todo.text;
    todoElement.appendChild(label);
}
for (let todo of todolist) {
    createAndAppendTodo(todo);
}